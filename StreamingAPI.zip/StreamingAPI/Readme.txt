Streaming API SAMPLE
-------------------------------
NCACHE FEATURES USED
--------------------
This sample deals with the following feature of NCache.
	i)	Streaming API

INTRODUCTION
------------
This is a sample application based on 'Streaming API' feature. 

DESCRIPTION
-----------
Streaming allows to read data from cache in chunks just like any buffered stream.

HOW TO RUN THE SAMPLE
---------------------

1. Open the solution.
2. The program is currently supposed to connect with a cache named "mypartitionedcache".
3. You can change the name of the cache in the NCache.Initialize() method.
4. Start the project named StreamingAPI.

Streaming API Settings:
-----------------------------

	Make sure the NCache service is running.


