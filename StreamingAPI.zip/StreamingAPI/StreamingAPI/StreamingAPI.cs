﻿using System;
using Alachisoft.NCache.Web.Caching;

// ===============================================================================
// Alachisoft (R) NCache Sample Code.
// NCache StreamingAPI sample
// ===============================================================================
// Copyright © Alachisoft.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
// ===============================================================================


namespace StreamingAPI
{
	public class StreamingAPI
	{
		public static void Main(string[] args)
		{
			try
			{
				//Streaming allows to read data from cache in chunks just like any buffered stream
				//Initialize cache

				Cache cache;
				cache = NCache.InitializeCache("mypartitionedcache");
				cache.Clear();

                //Declaring NCacheStream
                CacheStream stream;

				cache.Add("StreamingObject:1", new object[] {"StreamingObject:Value"});

				//StreamMode.Read allows only simultaneous reads but no writes!
                
                byte[] readBuffer = new byte[1024];
                int readCount;
                
                stream = cache.GetCacheStream("StreamingObject:1", StreamMode.Read);

                //Now you have stream perform operations on it just like any regular stream.
                
                readCount = stream.Read(readBuffer, 0, readBuffer.Length);
				stream.Close();

				//Must dispose cache
				cache.Dispose();

				Environment.Exit(0);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Environment.Exit(0);
			}

		}
	}

}